const mensagem = "Olá 🌎";
